# ============================================================================
# PROFESSIONAL STOCK PRICE PREDICTION SYSTEM - FINAL FIXED VERSION
# ============================================================================
import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Machine Learning & Deep Learning
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

print("="*80)
print("PROFESSIONAL STOCK PRICE PREDICTION SYSTEM")
print("="*80)

# ============================================================================
# 1. DATA COLLECTION
# ============================================================================
print("\n📊 PHASE 1: DATA COLLECTION")
print("-"*60)

# Download Apple (AAPL) stock data - last 3 years (shorter for faster training)
ticker = "AAPL"
end_date = datetime.now()
start_date = end_date - timedelta(days=3*365)  # 3 years of data

print(f"Downloading {ticker} stock data...")
stock_data = yf.download(ticker, start=start_date, end=end_date, progress=False)

# Check column structure and fix it
print(f"\nOriginal columns: {stock_data.columns.tolist()}")

# yfinance returns MultiIndex - handle it properly
if isinstance(stock_data.columns, pd.MultiIndex):
    # Flatten the MultiIndex columns
    stock_data.columns = ['_'.join(col).strip() for col in stock_data.columns.values]
else:
    # If already flat, keep as is
    pass

print(f"Flattened columns: {stock_data.columns.tolist()}")

# Simplify column names for easier access
column_mapping = {}
for col in stock_data.columns:
    if 'Close' in col:
        column_mapping[col] = 'Close'
    elif 'High' in col:
        column_mapping[col] = 'High'
    elif 'Low' in col:
        column_mapping[col] = 'Low'
    elif 'Open' in col:
        column_mapping[col] = 'Open'
    elif 'Volume' in col:
        column_mapping[col] = 'Volume'
    elif 'Adj Close' in col:
        column_mapping[col] = 'Adj_Close'

stock_data = stock_data.rename(columns=column_mapping)

print(f"✅ Data successfully downloaded")
print(f"   Date Range: {stock_data.index[0].date()} to {stock_data.index[-1].date()}")
print(f"   Shape: {stock_data.shape} (rows x columns)")
print(f"   Columns: {', '.join(stock_data.columns.tolist())}")

# Display first few rows
print("\n📋 Sample data:")
print(stock_data.head())

# ============================================================================
# 2. EXPLORATORY DATA ANALYSIS
# ============================================================================
print("\n📈 PHASE 2: EXPLORATORY DATA ANALYSIS")
print("-"*60)

# Display basic statistics
print("\n📌 Basic Statistics:")
print(stock_data.describe())

# Check for missing values
print("\n📌 Missing Values Analysis:")
print(stock_data.isnull().sum())

# Visualize the data
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle(f'{ticker} Stock Analysis Dashboard', fontsize=16, fontweight='bold')

# Plot 1: Closing Price Trend
axes[0,0].plot(stock_data['Close'], color='blue', linewidth=2)
axes[0,0].set_title('Closing Price Trend')
axes[0,0].set_xlabel('Date')
axes[0,0].set_ylabel('Price ($)')
axes[0,0].grid(True, alpha=0.3)

# Plot 2: Volume Analysis
axes[0,1].bar(stock_data.index, stock_data['Volume'], color='green', alpha=0.6)
axes[0,1].set_title('Trading Volume')
axes[0,1].set_xlabel('Date')
axes[0,1].set_ylabel('Volume')
axes[0,1].tick_params(axis='x', rotation=45)

# Plot 3: Daily Returns Distribution
daily_returns = stock_data['Close'].pct_change().dropna()
axes[0,2].hist(daily_returns, bins=50, edgecolor='black', alpha=0.7, color='purple')
axes[0,2].axvline(daily_returns.mean(), color='red', linestyle='--', label=f'Mean: {daily_returns.mean():.4f}')
axes[0,2].set_title('Daily Returns Distribution')
axes[0,2].set_xlabel('Daily Return')
axes[0,2].set_ylabel('Frequency')
axes[0,2].legend()

# Plot 4: Moving Averages (last 100 days)
if len(stock_data) >= 100:
    recent_data = stock_data.iloc[-100:]
    axes[1,0].plot(recent_data.index, recent_data['Close'], label='Close Price', linewidth=2)
    axes[1,0].plot(recent_data.index, recent_data['Close'].rolling(window=20).mean(), 
                   label='20-day MA', linestyle='--')
    axes[1,0].plot(recent_data.index, recent_data['Close'].rolling(window=50).mean(), 
                   label='50-day MA', linestyle='--')
    axes[1,0].set_title('Moving Averages (Last 100 Days)')
    axes[1,0].set_xlabel('Date')
    axes[1,0].set_ylabel('Price ($)')
    axes[1,0].legend()
    axes[1,0].tick_params(axis='x', rotation=45)
    axes[1,0].grid(True, alpha=0.3)
else:
    axes[1,0].text(0.5, 0.5, 'Insufficient data for 100-day MA', 
                   ha='center', va='center', transform=axes[1,0].transAxes)
    axes[1,0].set_title('Moving Averages')

# Plot 5: Correlation Heatmap
correlation = stock_data.corr()
sns.heatmap(correlation, annot=True, fmt='.2f', cmap='coolwarm', center=0, ax=axes[1,1])
axes[1,1].set_title('Feature Correlation Matrix')

# Plot 6: Volatility
if len(daily_returns) >= 20:
    volatility = daily_returns.rolling(window=20).std()
    axes[1,2].plot(volatility.index, volatility, color='orange', linewidth=2)
    axes[1,2].set_title('20-day Rolling Volatility')
    axes[1,2].set_xlabel('Date')
    axes[1,2].set_ylabel('Volatility')
    axes[1,2].grid(True, alpha=0.3)
else:
    axes[1,2].text(0.5, 0.5, 'Insufficient data for volatility', 
                   ha='center', va='center', transform=axes[1,2].transAxes)
    axes[1,2].set_title('Volatility')

plt.tight_layout()
plt.show()

# ============================================================================
# 3. FEATURE ENGINEERING
# ============================================================================
print("\n🔧 PHASE 3: FEATURE ENGINEERING")
print("-"*60)

# Create technical indicators and features
def create_features(df):
    df = df.copy()
    
    # Basic price features
    df['Returns'] = df['Close'].pct_change()
    df['Log_Returns'] = np.log(df['Close'] / df['Close'].shift(1))
    
    # Moving averages
    df['MA_5'] = df['Close'].rolling(window=5).mean()
    df['MA_10'] = df['Close'].rolling(window=10).mean()
    df['MA_20'] = df['Close'].rolling(window=20).mean()
    
    # Price ratios
    df['MA_Ratio_5'] = df['Close'] / df['MA_5']
    df['MA_Ratio_20'] = df['Close'] / df['MA_20']
    
    # Volatility
    df['Volatility_10'] = df['Returns'].rolling(window=10).std()
    
    # Price range
    df['High_Low_Pct'] = (df['High'] - df['Low']) / df['Close'] * 100
    df['Close_Open_Pct'] = (df['Close'] - df['Open']) / df['Open'] * 100
    
    # Volume indicators
    df['Volume_MA_10'] = df['Volume'].rolling(window=10).mean()
    df['Volume_Ratio'] = df['Volume'] / df['Volume_MA_10']
    
    # Lag features
    for lag in [1, 2, 3]:
        df[f'Close_Lag_{lag}'] = df['Close'].shift(lag)
    
    # Target variable: Price 3 days in the future
    df['Target'] = df['Close'].shift(-3)
    
    # Drop NaN values
    df = df.dropna()
    
    return df

# Apply feature engineering
stock_features = create_features(stock_data)
print(f"✅ Created {len(stock_features.columns)} features")
print(f"   Final shape: {stock_features.shape}")
print(f"\n📋 Feature List (first 10):")
for i, col in enumerate(stock_features.columns[:10], 1):
    print(f"   {i:2d}. {col}")

# ============================================================================
# 4. DATA PREPROCESSING
# ============================================================================
print("\n⚙️ PHASE 4: DATA PREPROCESSING")
print("-"*60)

# Separate features and target
X = stock_features.drop(['Target'], axis=1)
y = stock_features['Target']

print(f"Feature matrix shape: {X.shape}")
print(f"Target vector shape: {y.shape}")

# Scale the data
scaler_X = MinMaxScaler(feature_range=(0, 1))
scaler_y = MinMaxScaler(feature_range=(0, 1))

X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.values.reshape(-1, 1)).flatten()

# Split data (80% train, 20% test)
split_idx = int(0.8 * len(X_scaled))
X_train, X_test = X_scaled[:split_idx], X_scaled[split_idx:]
y_train, y_test = y_scaled[:split_idx], y_scaled[split_idx:]

print(f"\n✅ Data Split:")
print(f"   Training set: {X_train.shape[0]} samples ({split_idx} days)")
print(f"   Testing set: {X_test.shape[0]} samples")

# ============================================================================
# 5. MODEL BUILDING - SIMPLIFIED VERSION
# ============================================================================
print("\n🤖 PHASE 5: MODEL BUILDING & TRAINING")
print("-"*60)

# Dictionary to store models and predictions
models = {}
predictions = {}

# 5.1 LINEAR REGRESSION (Baseline)
print("\n📊 Training Linear Regression...")
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)
y_pred_lr = lr_model.predict(X_test)
models['Linear Regression'] = lr_model
predictions['Linear Regression'] = y_pred_lr
print("   ✅ Linear Regression trained")

# 5.2 RANDOM FOREST
print("🌲 Training Random Forest...")
rf_model = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
models['Random Forest'] = rf_model
predictions['Random Forest'] = y_pred_rf
print("   ✅ Random Forest trained")

# ============================================================================
# 6. MODEL EVALUATION
# ============================================================================
print("\n📊 PHASE 6: MODEL EVALUATION")
print("-"*60)

def evaluate_model(y_true_scaled, y_pred_scaled, model_name, scaler_y):
    """Evaluate model performance"""
    # Convert back to original scale
    y_true = scaler_y.inverse_transform(y_true_scaled.reshape(-1, 1)).flatten()
    y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
    
    # Calculate metrics
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    # Direction accuracy
    if len(y_true) > 1:
        direction_true = np.diff(y_true) > 0
        direction_pred = np.diff(y_pred) > 0
        direction_acc = np.mean(direction_true == direction_pred) * 100
    else:
        direction_acc = 0
    
    # Percentage error
    percentage_error = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    return {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'Direction_Accuracy': direction_acc,
        'Percentage_Error': percentage_error,
        'Predictions': y_pred,
        'Actual': y_true
    }

print("\n📌 MODEL PERFORMANCE METRICS:")
print("-"*40)

results = {}
for model_name in predictions:
    results[model_name] = evaluate_model(y_test, predictions[model_name], model_name, scaler_y)
    
    print(f"\n{model_name}:")
    print(f"  MAE: ${results[model_name]['MAE']:.2f}")
    print(f"  RMSE: ${results[model_name]['RMSE']:.2f}")
    print(f"  R² Score: {results[model_name]['R2']:.4f}")
    print(f"  Direction Accuracy: {results[model_name]['Direction_Accuracy']:.1f}%")
    print(f"  Average Error: {results[model_name]['Percentage_Error']:.2f}%")

# ============================================================================
# 7. VISUALIZATION OF RESULTS
# ============================================================================
print("\n📈 PHASE 7: RESULTS VISUALIZATION")
print("-"*60)

# Create results visualization
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle(f'{ticker} Stock Price Prediction Results', fontsize=14, fontweight='bold')

# Colors for different models
colors = ['blue', 'green', 'red', 'purple']

# Plot 1: Actual vs Predicted Prices
plot_days = min(50, len(y_test))
for idx, (model_name, color) in enumerate(zip(results.keys(), colors[:len(results)])):
    axes[0,0].plot(results[model_name]['Predictions'][:plot_days], 
                   label=model_name, color=color, alpha=0.7, linewidth=1.5)

axes[0,0].plot(results['Linear Regression']['Actual'][:plot_days], 
               label='Actual Price', color='black', linewidth=2, linestyle='--')
axes[0,0].set_title('Actual vs Predicted Prices')
axes[0,0].set_xlabel('Trading Days')
axes[0,0].set_ylabel('Price ($)')
axes[0,0].legend()
axes[0,0].grid(True, alpha=0.3)

# Plot 2: Model Performance Comparison
model_names = list(results.keys())
mae_values = [results[m]['MAE'] for m in model_names]
r2_values = [results[m]['R2'] for m in model_names]

x = np.arange(len(model_names))
width = 0.35

bars1 = axes[0,1].bar(x - width/2, mae_values, width, label='MAE ($)', color='skyblue')
bars2 = axes[0,1].bar(x + width/2, r2_values, width, label='R² Score', color='lightgreen')

axes[0,1].set_xlabel('Model')
axes[0,1].set_title('Model Performance Comparison')
axes[0,1].set_xticks(x)
axes[0,1].set_xticklabels(model_names)
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3, axis='y')

# Add value labels on bars
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        axes[0,1].text(bar.get_x() + bar.get_width()/2, height,
                      f'{height:.2f}', ha='center', va='bottom', fontsize=8)

# Plot 3: Error Distribution
for idx, (model_name, color) in enumerate(zip(results.keys(), colors[:len(results)])):
    errors = results[model_name]['Actual'] - results[model_name]['Predictions']
    axes[1,0].hist(errors, bins=30, alpha=0.5, label=model_name, color=color, edgecolor='black')

axes[1,0].axvline(x=0, color='black', linestyle='--', linewidth=2)
axes[1,0].set_title('Prediction Error Distribution')
axes[1,0].set_xlabel('Prediction Error ($)')
axes[1,0].set_ylabel('Frequency')
axes[1,0].legend()
axes[1,0].grid(True, alpha=0.3)

# Plot 4: Scatter Plot
for idx, (model_name, color) in enumerate(zip(results.keys(), colors[:len(results)])):
    axes[1,1].scatter(results[model_name]['Actual'], 
                      results[model_name]['Predictions'], 
                      alpha=0.6, s=30, color=color, label=model_name)

# Perfect prediction line
all_actual = np.concatenate([results[m]['Actual'] for m in results])
all_preds = np.concatenate([results[m]['Predictions'] for m in results])
max_val = max(all_actual.max(), all_preds.max())
min_val = min(all_actual.min(), all_preds.min())

axes[1,1].plot([min_val, max_val], [min_val, max_val], 'k--', linewidth=2, label='Perfect Prediction')
axes[1,1].set_xlabel('Actual Price ($)')
axes[1,1].set_ylabel('Predicted Price ($)')
axes[1,1].set_title('Predicted vs Actual Prices')
axes[1,1].legend()
axes[1,1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# ============================================================================
# 8. FEATURE IMPORTANCE ANALYSIS
# ============================================================================
print("\n🔍 PHASE 8: FEATURE IMPORTANCE ANALYSIS")
print("-"*60)

# Get feature importance from Random Forest
feature_importance = pd.DataFrame({
    'Feature': X.columns,
    'Importance': rf_model.feature_importances_
}).sort_values('Importance', ascending=False)

print("\n📊 Top 10 Most Important Features:")
print("-"*30)
for i, row in feature_importance.head(10).iterrows():
    print(f"{i+1:2d}. {row['Feature']}: {row['Importance']:.4f}")

# Plot feature importance
plt.figure(figsize=(10, 6))
top_features = feature_importance.head(10)
plt.barh(range(len(top_features)), top_features['Importance'][::-1])
plt.yticks(range(len(top_features)), top_features['Feature'][::-1])
plt.xlabel('Importance')
plt.title('Top 10 Feature Importances (Random Forest)')
plt.grid(True, alpha=0.3, axis='x')
plt.tight_layout()
plt.show()

# ============================================================================
# 9. FUTURE PREDICTION & RECOMMENDATIONS
# ============================================================================
print("\n🔮 PHASE 9: FUTURE PREDICTION & RECOMMENDATIONS")
print("-"*60)

# Get the best model
best_model_name = max(results, key=lambda x: results[x]['R2'])
best_model = models[best_model_name]
best_r2 = results[best_model_name]['R2']

current_price = stock_data['Close'].iloc[-1]
avg_error = results[best_model_name]['MAE']

print(f"\n📊 SUMMARY FOR {ticker}:")
print("-"*40)
print(f"Current Price: ${current_price:.2f}")
print(f"Best Model: {best_model_name}")
print(f"Model R² Score: {best_r2:.4f}")
print(f"Average Prediction Error: ±${avg_error:.2f}")

print(f"\n🎯 3-DAY PRICE FORECAST:")
print("-"*30)

# Simple forecast based on recent trend
recent_trend = stock_data['Close'].pct_change().tail(5).mean()

if recent_trend > 0:
    forecast = current_price * (1 + recent_trend)
    trend_direction = "UPWARD"
else:
    forecast = current_price * (1 + recent_trend)
    trend_direction = "DOWNWARD"

print(f"Current Trend: {trend_direction}")
print(f"Expected Range: ${current_price - avg_error:.2f} - ${current_price + avg_error:.2f}")
print(f"Trend-based Forecast: ${forecast:.2f}")

print(f"\n💡 TRADING RECOMMENDATIONS:")
print("-"*30)
if best_r2 > 0.7:
    print("✅ Model shows good predictive power")
    print("✅ Consider using predictions as trading signals")
elif best_r2 > 0.5:
    print("⚠️ Model shows moderate predictive power")
    print("⚠️ Use predictions as supplementary information only")
else:
    print("❌ Model predictive power is low")
    print("❌ Rely more on fundamental analysis")

print(f"\n📈 MARKET ANALYSIS:")
print("-"*30)
volatility = daily_returns.std() * 100
print(f"Market Volatility: {volatility:.2f}%")

if volatility > 2:
    print("⚠️ High volatility market - Increased risk")
    print("✅ Opportunity for swing trading")
else:
    print("✅ Stable market conditions")
    print("✅ Suitable for position trading")

print(f"\n🎯 RISK MANAGEMENT SUGGESTIONS:")
print("-"*30)
stop_loss = current_price * 0.97  # 3% stop loss
take_profit = current_price * 1.05  # 5% take profit
print(f"Recommended Stop Loss: ${stop_loss:.2f}")
print(f"Recommended Take Profit: ${take_profit:.2f}")
print(f"Risk-Reward Ratio: 1:{5/3:.1f}")

# ============================================================================
# 10. SAVE RESULTS
# ============================================================================
print("\n💾 PHASE 10: SAVING RESULTS")
print("-"*60)

# Create results summary
results_summary = pd.DataFrame({
    'Model': list(results.keys()),
    'MAE': [results[m]['MAE'] for m in results],
    'RMSE': [results[m]['RMSE'] for m in results],
    'R2': [results[m]['R2'] for m in results],
    'Direction_Accuracy_%': [results[m]['Direction_Accuracy'] for m in results]
})

# Save to CSV
results_summary.to_csv('stock_prediction_results.csv', index=False)
print("✅ Results saved to 'stock_prediction_results.csv'")

# Save feature importance
feature_importance.to_csv('feature_importance.csv', index=False)
print("✅ Feature importance saved to 'feature_importance.csv'")

# Save predictions
predictions_df = pd.DataFrame({
    'Actual': results['Linear Regression']['Actual'],
    'LR_Prediction': results['Linear Regression']['Predictions'],
    'RF_Prediction': results['Random Forest']['Predictions']
})
predictions_df.to_csv('predictions.csv', index=False)
print("✅ Predictions saved to 'predictions.csv'")

print("\n" + "="*80)
print("✅ STOCK PRICE PREDICTION PROJECT COMPLETED SUCCESSFULLY!")
print("="*80)

print(f"\n📊 FINAL SUMMARY:")
print("-"*40)
print(f"Stock: {ticker}")
print(f"Period: {stock_data.index[0].date()} to {stock_data.index[-1].date()}")
print(f"Best Model: {best_model_name}")
print(f"Prediction Accuracy: {best_r2*100:.1f}%")
print(f"Average Error: ±${avg_error:.2f} ({avg_error/current_price*100:.1f}%)")
print(f"Recommendation: {'Use with confidence' if best_r2 > 0.7 else 'Use cautiously'}")